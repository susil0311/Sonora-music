package com.music.bitchord.playback

import android.net.Uri
import android.util.Log
import com.music.bitchord.data.TrackLog
import com.music.bitchord.data.NerdStats
import com.music.bitchord.data.sources.SourceResolver
import com.music.bitchord.data.sources.SourceStream
import com.music.bitchord.data.sources.StreamFormat
import com.music.bitchord.data.sources.StreamRequest
import com.music.bitchord.data.sources.TrackMatcher
import kotlinx.coroutines.Deferred
import java.util.concurrent.ConcurrentHashMap

/**
 * The second look: a track that started on less than was asked for gets the
 * question asked again, properly, while it plays.
 *
 * The live path has to answer in the time a listener will wait for a track to
 * start, and it buys that by giving up on the slow catalogue — which is
 * regularly the one holding the lossless copy. Measured on this device: the
 * fastest module answered a search in 1.3s and the slowest in 5.4s, and the
 * slow one then took a further 8.2s to walk its own fallback chain down to a
 * 128kbps MP3. Waiting for all of that costs 14 seconds of silence; not
 * waiting costs the FLAC. Neither is a good trade, and neither has to be made
 * once the search can happen with sound already coming out of the speaker.
 *
 * So: play whatever can be had now, then look again with no time limit, and
 * swap only if the answer is genuinely the same recording *and* genuinely
 * better than what is playing — which is usually the lossless copy that was
 * asked for, but is also a 320kbps module stream against YouTube's 160kbps
 * Opus. See [SourceResolver.worthSwapping] for where that line is drawn.
 * The swap is not free — ExoPlayer cannot change sources
 * gaplessly mid-track, so there is a short break in the audio — which is why
 * every guard here errs towards not doing it. A missed upgrade is a quieter
 * failure than an interrupted song.
 *
 * ### How the swap reaches the player
 *
 * The queue holds `bitchord://watch?v=…` URIs that
 * [PlaybackService][PlaybackService]'s resolving data source turns into real
 * URLs at open time. An upgrade re-points that indirection rather than
 * touching the queue: the stream is parked in [forced], the item is replaced
 * with the same URI plus a `q=` marker, and the marker does two jobs — it
 * makes the item unequal to its old self so Media3 actually rebuilds the media
 * source, and it keys the disk cache separately so the FLAC is not written
 * into the middle of the half-cached MP3 it is replacing.
 */
object QualityUpgrade {

    private const val TAG = "BitChord"

    /** The marker that distinguishes an upgraded item from the one it replaced. */
    const val MARKER = "q"
    private const val UPGRADED = "hifi"

    /** What a revert tags its rendition with — see [Song.toDirectYouTubeMediaItem]. */
    private const val ORIGINAL = "original"

    /**
     * A track playing on less than was asked for.
     *
     * [inFlight] is the live lookup that lost the race rather than ran out of
     * answers — still running, and worth waiting on rather than repeating,
     * because whatever it returns is precisely the stream that would have
     * played had it been quicker. Null once the live path has finished and
     * come back with nothing better; the second look then has to go find its
     * own candidates.
     */
    private data class Pending(
        val target: TrackMatcher.Target,
        val inFlight: Deferred<SourceStream?>? = null,
        /**
         * What the listener is actually hearing — the yardstick a lossy
         * candidate is measured against in [SourceResolver.worthSwapping].
         * Known by the time a track is marked pending: whichever stream won
         * the race has already named its format, and a track adopted from the
         * cache without a race has one measured for it — see
         * [adoptUnresolved]. Null only when neither could, and an unknown
         * floor is one nothing lossy clears.
         */
        val playing: StreamFormat? = null,
        /**
         * The source already serving this track, if known — see
         * [SourceResolver.upgradeFor]'s own `servedBy`. Left out of the second
         * look so a deterministic catalogue isn't asked the same question
         * twice for a rejection it already gave the first time.
         */
        val servedBy: String? = null,
    )

    private val pending = ConcurrentHashMap<String, Pending>()
    /**
     * A second pass to make after a worthwhile lossy upgrade.  The first pass
     * intentionally takes the first source that beats Opus so playback improves
     * quickly; with lossless requested, JioSaavn can be that answer while a
     * slower FLAC source is still searching. Once JioSaavn is playing, ask
     * again with its bitrate as the floor: it is then rejected as unchanged and
     * the slower lossless source gets a chance to win. Dolby Atmos is final too:
     * it is lossy by codec definition, but it is the completed immersive tier,
     * not an interim copy to search over and swap to again.
     */
    private val followUps = ConcurrentHashMap<String, Pending>()
    private val forced = ConcurrentHashMap<String, SourceStream>()

    internal fun needsLosslessFollowUp(format: StreamFormat): Boolean =
        SourceResolver.requestForNow() is StreamRequest.Lossless &&
            format.isLossless != true &&
            !format.isDolbyAtmos

    /**
     * Tracks whose upgraded stream is being *proved* rather than played — see
     * [PlaybackService][com.music.bitchord.playback.PlaybackService]'s
     * audition.
     *
     * An audition reaches its bytes through the same resolving data source the
     * real player does, which is where [forcedStream] hands over the URL and
     * where the format it promises is recorded for "stats for nerds". That
     * recording is right for a stream being played and wrong for one being
     * tried out: for the length of an audition the listener is still hearing
     * the old stream, and a badge that reads "Lossless" over it is describing
     * a swap that has not happened and might never.
     */
    private val auditioning = java.util.Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())

    fun beginAudition(mediaId: String) {
        auditioning += mediaId
    }

    fun endAudition(mediaId: String) {
        auditioning -= mediaId
    }

    /** Whether the fetch about to happen for [videoId] is an audition, not playback. */
    fun isAuditioning(videoId: String?): Boolean = videoId != null && videoId in auditioning

    /**
     * Upgrades that were found, proved and cached, and then never got to
     * happen because the queue moved on in the last moments before the swap.
     *
     * Everything expensive about an upgrade is already spent by that point —
     * the catalogue search, the audition, the megabytes on disk — and all of it
     * was being thrown away over a quarter of a second of timing. Measured: a
     * FLAC found in 10.1s, proved in 2.0s and cached in full, discarded because
     * the listener skipped 254ms before the swap; skipping straight back to the
     * track could not use any of it.
     *
     * Held against exactly that — the listener coming back. The stream stays in
     * [forced] and its bytes stay under the rendition key, so the swap that
     * follows is the cheap kind: no search, no download, and an audition that
     * reads from disk.
     */
    private val shelved = ConcurrentHashMap<String, SourceStream>()

    /** Keeps a proved-but-unused upgrade for [mediaId] against a return visit. */
    fun shelve(mediaId: String, stream: SourceStream) {
        shelved[mediaId] = stream
        // The answer was yes. Recording it as a settled question is what would
        // stop [couldStillUpgrade] ever offering the track again.
        asked -= mediaId
    }

    /** The upgrade already proved for [mediaId], if one ran out of track. */
    fun shelvedFor(mediaId: String): SourceStream? = shelved[mediaId]

    /**
     * Takes [mediaId]'s upgrade off the shelf — it has happened.
     *
     * Without this the entry outlives the swap it describes, and the next time
     * the listener comes back to the track it is offered again: the item URI
     * already carries the marker, so the swap declines, and the decline is read
     * as another missed one and shelved afresh.
     */
    fun unshelve(mediaId: String) {
        shelved.remove(mediaId)
    }

    /**
     * Records that [mediaId] is playing on less than was asked for — whether
     * that is a lossy stream a module handed over, or YouTube's own because no
     * module answered in time.
     *
     * Called from the resolving data source, which is the only place that
     * knows both what was requested and what actually came back. The track
     * stays in [NerdStats.racingLossless] from here until the second look
     * finishes, so the player keeps saying "Loading lossless" rather than
     * going blank and then possibly changing its mind — the badge should
     * describe the search that is genuinely still running, and go out for good
     * once the answer is known to be no.
     *
     * Does nothing unless lossless is what the connection and the settings
     * currently add up to. There is no such thing as an upgrade from a stream
     * that is already everything that was asked for, and marking one pending
     * would light the badge for a search with no possible outcome.
     */
    fun settledForLess(
        mediaId: String,
        target: TrackMatcher.Target,
        inFlight: Deferred<SourceStream?>? = null,
        playing: StreamFormat? = null,
        servedBy: String? = null,
    ): Boolean {
        // Not gated on the request being lossless. A source ranked above
        // YouTube can be worth swapping to on bitrate alone — see
        // [SourceResolver.worthSwapping] — and requiring lossless here meant a
        // lookup that was still running got cancelled outright the moment
        // YouTube won the race, so a 320kbps source never finished and never
        // played. [SourceResolver.upgradeFor] applies the real quality bar.
        if (target.title.isBlank() || target.isVideo ||
            mediaId in refused ||
            !SourceResolver.canSubstituteForYouTube()
        ) {
            inFlight?.cancel()
            return false
        }
        pending[mediaId] = Pending(target, inFlight, playing, servedBy)
        NerdStats.onLosslessRaceStart(mediaId)
        TrackLog.d(
            TAG,
            if (inFlight != null) {
                "'${target.title}' started on the fallback; its lookup is still running"
            } else {
                "below request for '${target.title}'; will look again during playback"
            },
            about = mediaId,
        )
        return true
    }

    /** Whether [mediaId] is worth a second look — and hasn't already had one. */
    fun isPending(mediaId: String?) = mediaId != null && pending.containsKey(mediaId)

    /**
     * Tracks whose upgrade broke the playback it was supposed to improve.
     *
     * A swapped-in stream that fails to serve its bytes costs a cut in the
     * audio and a recovery, and the search that produced it is deterministic —
     * ask again and the same catalogue returns the same dead URL. Nothing here
     * expires on a timer: the entry is worth exactly as long as the player that
     * broke on it, and [forgetLastSession] is what draws that line. It used to
     * read "cleared with the rest when the process goes", which is a lifetime
     * this map does not have — see there.
     */
    private val refused = java.util.Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())

    /**
     * Stops offering [mediaId] any further upgrades this session — its last
     * one is what killed it. Called from the recovery path; see
     * [PlaybackService][com.music.bitchord.playback.PlaybackService].
     */
    fun refuseUpgrades(mediaId: String) {
        refused += mediaId
        TrackLog.d(TAG, "$mediaId broke on its upgrade; no more swaps for it", about = mediaId)
    }

    /**
     * Tracks that have already had their second look, whether it found
     * anything or not.
     *
     * [pending] cannot answer this on its own, because [lookAgain] empties it
     * as the question is asked: by the next progress sample a track that has
     * been asked about and a track that was never a candidate look identical.
     * That distinction costs nothing on the resolve path — nothing marks a
     * track pending twice — but it is the whole difference for
     * [adoptUnresolved], which is offered the same playing track every five
     * seconds for as long as it lasts.
     */
    private val asked = java.util.Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())

    /**
     * Whether [mediaId] is worth *evaluating* for a second look, given that
     * nothing has resolved it.
     *
     * The cheap half of [adoptUnresolved], split out because it is asked on the
     * main thread every progress sample while the other half has to wait for
     * the decoder to settle first. Everything here is a fact about the queue
     * entry and the settings; nothing here touches the network.
     */
    fun couldStillUpgrade(mediaId: String, uri: Uri?): Boolean {
        if (uri == null || uri.getQueryParameter("v") == null ||
            uri.getQueryParameter("m") == "1"
        ) return false
        // Already upgraded: this *is* the better copy. Except when the listener
        // has asked by hand, where the marker is on a *reverted* item and
        // saying "this is the copy that was chosen" is the very thing being
        // overruled — see [askByHand].
        if (mediaId !in handAsked && uri.getQueryParameter(MARKER) != null) return false
        if (mediaId in asked || mediaId in refused || pending.containsKey(mediaId)) return false
        // Direct Source Stream never swaps an addon's answer on its own. A track
        // it had to start on YouTube is still looked for, as it is with the
        // setting off. Asking by hand always works: that is the listener
        // overruling the copy, not a background hunt.
        if (mediaId !in handAsked && DirectSourceGate.isActive() && !StreamChoice.isYouTube(mediaId)) {
            return false
        }
        // Same widening as [settledForLess]: a track playing off the cache is
        // worth a second look whenever anything outranks YouTube, not only
        // when lossless was asked for.
        return SourceResolver.canSubstituteForYouTube()
    }

    /**
     * Marks a track that is playing without ever having been resolved.
     *
     * [settledForLess] is reached from the resolving data source, which is the
     * only place that knows what was asked for and what came back — and which
     * a track playing off the disk cache never reaches at all. `CacheDataSource`
     * wraps the resolver rather than the other way round, so bytes already on
     * disk are served without a resolve, without a lookup, and so without
     * anything marking the track worth a second look. The tracks that hit this
     * hardest are the ones restored into the queue at startup: their bytes were
     * written by a previous process, so nothing in *this* one has ever asked a
     * module about them, and they would play at last session's bitrate for the
     * rest of the session and every session after it, while a freshly queued
     * copy of the same song upgraded within seconds.
     *
     * @param playingMime what the *decoder* says about the bytes it is being
     *   fed, and it must be this track's — see
     *   [PlaybackService.audioFormatFor][com.music.bitchord.playback.PlaybackService].
     *   The one thing worth not doing here is hunting a lossless copy of a
     *   track that is already playing one, which is exactly what a cache entry
     *   written by a previous session's successful upgrade holds.
     * @param playing how good those bytes are, for
     *   [SourceResolver.worthSwapping] to weigh candidates against — measured
     *   off the decoder or off the cache entry's own size, never from a
     *   resolver figure, because there was no resolve.
     *
     *   This used to be hardcoded null, on the reasoning that a lossy stream
     *   from the cache cannot say what bitrate it is and an unknown floor is
     *   the conservative choice. It is not conservative; it is a floor nothing
     *   lossy clears, which quietly narrowed the whole path to lossless-only.
     *   Measured on the track that was reported — 'The Night We Met', upgraded
     *   to Tidal's AAC 320 in one session and restarted into its YouTube Opus:
     *
     *   ```
     *     17:39:47.471  90DKXLbzLto <- audio/opus 48.0kHz bitrate n/a
     *     17:39:47.518  is playing from cache and was never resolved; looking…
     *     17:39:55      three candidates, each "offered 320 kbps; looking further"
     *     ——— nothing ———
     *   ```
     *
     *   The second look ran, found the same 320kbps copy it had swapped in
     *   twenty minutes earlier, and [SourceResolver.worthSwapping] dropped all
     *   three on `playing?.kbps ?: return false`. There is no lossless copy of
     *   that track behind any configured module — the one advertising FLAC in
     *   search serves AAC from its stream endpoint — so the listener got the
     *   "Upgrading Quality" badge, then silence on it, then Opus for the rest
     *   of the session. Against the real floor the gain is 320 − ~160, which
     *   clears [SourceResolver.worthSwapping]'s minimum twice over.
     * @return true if the track is now pending, i.e. worth calling
     *   [lookAgain] for.
     */
    fun adoptUnresolved(
        mediaId: String,
        uri: Uri,
        target: TrackMatcher.Target,
        playingMime: String?,
        playing: StreamFormat?,
    ): Boolean {
        if (!couldStillUpgrade(mediaId, uri)) return false
        // [asked] is set only on the two *verdicts* below, not on adoption.
        // Both are facts about the bytes on disk and the row that queued them,
        // neither changes while the track plays, and neither is worth
        // re-deciding every five seconds. A track that gets adopted needs no
        // entry here at all: [pending] keeps [couldStillUpgrade] off it for
        // exactly as long as the question is genuinely open, and marking it
        // answered before it has been asked is what made a skip permanent.
        // Dolby Atmos counts as done too, as it does everywhere else here — see
        // [needsLosslessFollowUp]. A whole addon file now stays in the cache, so
        // an Atmos mix can be replayed from disk, and [cachedFloor] describes it
        // only by bitrate: judged as lossy, it would have a stereo FLAC cut in
        // over the mix the listener chose.
        if (NerdStats.isLosslessMime(playingMime) || NerdStats.isDolbyAtmosMime(playingMime)) {
            asked += mediaId
            // The codec is named because this line is a dead end — the track is
            // in [asked] by now and will never be offered an upgrade again — and
            // without it there is no way to tell a correct verdict from one
            // reached on the previous track's format.
            TrackLog.d(
                TAG,
                "'${target.title}' is already playing $playingMime from cache; no second look needed",
                about = mediaId,
            )
            return false
        }
        if (target.title.isBlank()) {
            asked += mediaId
            return false
        }
        pending[mediaId] = Pending(target, inFlight = null, playing = playing)
        NerdStats.onLosslessRaceStart(mediaId)
        TrackLog.d(
            TAG,
            "'${target.title}' is playing ${playing?.summary ?: "an unmeasured stream"} from cache " +
                "and was never resolved; looking for a better copy",
            about = mediaId,
        )
        return true
    }

    /**
     * Looks for a stream that actually satisfies the request, for a track
     * already playing.
     *
     * The track stays in [NerdStats.racingLossless] when this returns a stream
     * — the caller ends it once the swap has landed or been given up on. The
     * badge describes the *upgrade*, not the search behind it, and those stop
     * being the same thing as soon as the search can finish before the track
     * it was for comes round. That is now the ordinary case: a track is
     * resolved while its predecessor plays, so by the time a listener is
     * hearing it the lookup has often been sitting on the answer for a minute.
     * Ended here, "Upgrading Quality" was drawn for the few milliseconds
     * between the track becoming current and this returning, and the audio
     * then changed five seconds later with nothing on screen having said so.
     *
     * @param playingDurationSec the runtime the *decoder* reports, which is
     *   the one thing here that is measured rather than claimed. A candidate
     *   has to match it — see [SourceResolver.upgradeFor].
     * @return the better stream, or null if there isn't one, in which case
     *   this track is never asked about again.
     */
    /**
     * Computes the duration to match against during an upgrade.
     * When runtime decoder duration differs severely from the known catalogue
     * duration (e.g. a 3:29 video edit playing for a 5:02 album track), the
     * authoritative catalogue duration is preserved so the correct recording can
     * be found.
     */
    fun effectiveTargetDuration(expectedSec: Int?, playingSec: Int?): Int? {
        return if (expectedSec != null && playingSec != null &&
            TrackMatcher.isSevereMismatch(expectedSec, playingSec)
        ) {
            expectedSec
        } else {
            playingSec ?: expectedSec
        }
    }

    suspend fun lookAgain(mediaId: String, playingDurationSec: Int?): SourceStream? {
        val waiting = pending[mediaId] ?: return null
        var found: SourceStream? = null
        /**
         * Whether the search got as far as an answer, as opposed to being
         * cancelled on its way to one. The difference is the whole of what
         * [asked] is allowed to mean.
         */
        var answered = false
        val expectedSec = waiting.target.durationSec
        val effectiveDurationSec = effectiveTargetDuration(expectedSec, playingDurationSec)
        if (expectedSec != null && playingDurationSec != null &&
            TrackMatcher.isSevereMismatch(expectedSec, playingDurationSec)
        ) {
            TrackLog.w(
                TAG,
                "playing duration ($playingDurationSec s) drifted severely from catalogue duration ($expectedSec s); preserving catalogue duration for upgrade",
                about = mediaId,
            )
        }
        return try {
            // The lookup that was still running when the fallback won the race
            // gets first refusal: what it returns is the stream that would
            // have played with no seam at all had it been a few seconds
            // quicker.
            //
            // It is not taken on trust, though, and the reason is the whole
            // difference between where it was going to be used and where it is
            // used now. The live path's match is made against a runtime
            // *claimed* by whoever queued the track, and where nothing in the
            // results agrees with that runtime, [SourceResolver.preferred]
            // lets the title and artist decide alone — correctly, for picking
            // what to play from the start. Cutting into a track already
            // playing is a stricter question, and it gets the stricter test
            // that [SourceResolver.upgradeFor] applies to its own candidates,
            // against the length the decoder is reporting. Measured here, the
            // difference was a 189-second cut swapped into a 163-second song,
            // which played for five seconds of silence and was then put back.
            waiting.inFlight?.let { lookup ->
                val late = runCatching { lookup.await() }.getOrNull()
                val slack = SourceResolver.upgradeSlackSec()
                val sameLength = late != null &&
                    SourceResolver.sameRecordingAs(late.durationSec, effectiveDurationSec, slack)
                // The live lookup logs "substituted … at <format>" on finding
                // this, so a refusal that said nothing read as a swap that had
                // happened. Named, with both runtimes and the bar between them.
                if (late != null && !sameLength) {
                    TrackLog.d(
                        TAG,
                        "'${waiting.target.title}': the live lookup's ${late.format.summary} runs " +
                            "${late.durationSec ?: "?"}s against ${effectiveDurationSec ?: "?"}s playing, " +
                            "outside the ±${slack}s tolerance; searching again",
                        about = mediaId,
                    )
                }
                if (late != null && sameLength &&
                    SourceResolver.worthSwapping(late.format, waiting.playing)
                ) {
                    found = late
                    if (needsLosslessFollowUp(late.format)) {
                        followUps[mediaId] = waiting.copy(
                            target = waiting.target.copy(durationSec = effectiveDurationSec),
                            inFlight = null,
                            playing = late.format,
                            servedBy = late.sourceConfigId,
                        )
                    }
                    answered = true
                    return late
                }
            }
            // It finished with nothing better, so the question gets asked
            // again from scratch — this time waiting on every module, which is
            // what the live path could not afford to do. The source already
            // serving the track is left out — see [SourceResolver.upgradeFor].
            SourceResolver.upgradeFor(
                waiting.target.copy(durationSec = effectiveDurationSec),
                playing = waiting.playing,
                servedBy = waiting.servedBy,
            ).also {
                found = it
                if (it != null && needsLosslessFollowUp(it.format)) {
                    followUps[mediaId] = waiting.copy(
                        target = waiting.target.copy(durationSec = effectiveDurationSec),
                        inFlight = null,
                        playing = it.format,
                        servedBy = it.sourceConfigId,
                    )
                }
                answered = true
            }
        } finally {
            if (answered) {
                // The question has now been asked, whatever the answer. Leaving
                // it pending would re-run the whole search on every pause and
                // resume, and leaving it out of [asked] would let
                // [adoptUnresolved] offer the same track again at the next
                // progress sample.
                pending.remove(mediaId)
                asked += mediaId
            }
            // Otherwise the search was cancelled — the queue moved on while it
            // was still running — and *nothing was learned*. The track is left
            // exactly as it was found: still pending, still worth asking about
            // if the listener comes back to it.
            //
            // It was not, and that was the single biggest hole in this feature.
            // Two seconds on another track was enough to record a search that
            // never finished as a settled "nothing better exists", and the
            // track then played on at its original bitrate for the rest of the
            // session with no badge, no search and no way back:
            //
            // ```
            //   21:36:44  'double take' … looking for a better copy
            //   21:36:46  TIMING track selected: e-9zmBhCfmk
            //   21:36:48  TIMING track selected: IYOfGK5Zos4   ← and nothing
            // ```
            //
            // Only a *no* ends the race here. A yes leaves the badge up for
            // the caller to close out when the swap it describes has actually
            // happened — see this function's own documentation.
            if (found == null) NerdStats.onLosslessRaceEnd(mediaId)
        }
    }

    /**
     * A fresh play of [mediaId] has begun on [uri] — re-open a verdict that no
     * longer describes what is playing.
     *
     * [asked] means "this track has had its second look", and the comment on it
     * scopes that to one playback: *for as long as it lasts*. Nothing enforced
     * the scope. The set is keyed by media id alone and survives the track
     * ending, so playing the same song twice in one session went:
     *
     * ```
     *   23:38:28  substituted: 'Gehra Hua' … over YouTube at Dolby Atmos   ← asked += i1o1p_DD6TU
     *   23:44:07  TIMING track selected: i1o1p_DD6TU (reason=3)            ← and nothing at all
     * ```
     *
     * The second play is a different stream from the one the verdict was
     * reached about. The upgraded bytes live under their own rendition key and
     * the marked item URI went with the queue entry that carried it, so a
     * fresh entry reads the *base* cache entry — the 146kbps Opus YouTube
     * served before the upgrade — and [couldStillUpgrade] then refuses it a
     * second look on the strength of a yes that applied to the copy it is no
     * longer playing. The track plays worse the second time than the first,
     * for the rest of the process, and silently: this is the cheap main-thread
     * check, so nothing is logged when it says no.
     *
     * Guarded on the marker rather than cleared unconditionally. An item that
     * *is* the upgraded copy — or a hand-reverted `q=original` — is already
     * excluded by [couldStillUpgrade] on its own terms, and re-opening those
     * would have the swap that just happened looked for again. And this is a
     * transition, not a progress sample, so it cannot reinstate the every-five-
     * seconds offer that [asked] exists to prevent: pausing and resuming does
     * not come through here.
     *
     * @param rendition the item's [MARKER], via [cacheTag] — null for an
     *   ordinary queue entry, set on an upgraded or hand-reverted one. Taken
     *   as the marker rather than as the `Uri` it came from because that is
     *   the whole of what this reads, and because `Uri` is a framework stub
     *   under unit test.
     */
    fun onPlaybackStarted(mediaId: String, rendition: String?) {
        if (rendition != null) return
        asked -= mediaId
    }

    /**
     * Whether [mediaId] is *known* to be playing YouTube's own copy, so the
     * player menu should offer to upgrade it rather than to revert it.
     *
     * The menu used to read this off [OriginalVersion][com.music.bitchord.playback.OriginalVersion]'s
     * pin alone, which only a listener's own revert ever sets. An upgrade that
     * is found, swapped in and then fails to prove itself puts the track back
     * on the stream it came from — see the revert path in
     * [PlaybackService][com.music.bitchord.playback.PlaybackService] — and
     * nothing pins anything, so the menu went on offering "Revert to original"
     * for a track already playing YouTube's Opus. The row did nothing, and the
     * one row that would have helped was the one it was standing in front of.
     *
     * Both halves are required, and each rules out a different wrong answer:
     *
     *  - **No upgrade marker on the item.** [StreamChoice] records the copy the
     *    *first* resolve settled on and is not cleared when an upgrade swaps a
     *    better one in, so on a successfully upgraded track it still names
     *    YouTube. The marker is what says the swap happened, and a track
     *    playing its upgraded copy is exactly the one that should be offered
     *    the revert.
     *  - **A recorded choice that is not a substitute.** `null` means nothing
     *    resolved this track in this process — it is playing off the disk cache.
     *    The entry's own origin tag answers it then, see [cachedOrigin]. Only
     *    an entry with no tag is genuinely unknown, and revert stays on offer
     *    there as the escape hatch for a substitution nothing announced.
     *
     * @param cachedOrigin who filled the cache entry the item reads from — see
     *   [AudioCache.originOf]. Without it every track replayed from the cache
     *   after a restart read as unknown, which is every such track: the menu
     *   offered "Revert to original" over YouTube's own Opus and hid "Upgrade
     *   quality", the one row that could have helped.
     */
    fun isKnownToBePlayingYouTubesOwn(
        mediaId: String,
        rendition: String?,
        cachedOrigin: AudioCache.Origin? = null,
    ): Boolean {
        if (rendition != null) return false
        if (StreamChoice.of(mediaId) != null) return !StreamChoice.isSubstitute(mediaId)
        return cachedOrigin == AudioCache.Origin.YOUTUBE
    }

    /**
     * Test seam. [couldStillUpgrade] cannot answer this on its own — it also
     * consults [SourceResolver.canSubstituteForYouTube], which needs a
     * populated registry — so the verdict is read directly to keep the scoping
     * of [asked] testable without standing a source list up around it.
     */
    internal fun hasAnsweredFor(mediaId: String): Boolean = mediaId in asked

    /** Test seam: puts [mediaId] in the state a completed second look leaves it. */
    internal fun markAnsweredForTest(mediaId: String) {
        asked += mediaId
    }

    /** Abandons the second look for [mediaId] — the queue has moved on. */
    fun forget(mediaId: String) {
        pending.remove(mediaId)?.inFlight?.cancel()
        followUps.remove(mediaId)?.inFlight?.cancel()
        forced.remove(mediaId)
        shelved.remove(mediaId)
        auditioning -= mediaId
        // A request made by hand is about the track the listener was listening
        // to. Once the queue has moved off it there is nothing left to honour,
        // and an exemption that outlived its moment would let the next visit to
        // the track re-run a search that has already been answered.
        handAsked -= mediaId
        NerdStats.onLosslessRaceEnd(mediaId)
    }

    /**
     * Tracks the listener has asked to upgrade themselves.
     *
     * The one exemption from [couldStillUpgrade]'s marker rule, and it needs to
     * be an exemption rather than a rewritten item. A reverted track is playing
     * its `q=original` rendition; the ordinary way to make it a candidate again
     * would be to put the unmarked item back, and that costs a break in the
     * audio *before* anything better has even been looked for — the listener
     * hears the same YouTube copy stop and restart, and then stop again when
     * the upgrade actually lands. Two cuts, one of which bought nothing.
     *
     * Left in place, the marked item is upgraded exactly like any other: the
     * search runs under the music, the audition proves the replacement, and
     * [upgradedUri] takes the `direct_youtube` out of the URI it builds so the
     * one cut the listener does hear is the one that changes the audio.
     */
    private val handAsked = java.util.Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())

    /**
     * Re-opens the upgrade question for [mediaId] because the listener asked
     * it — the player menu's "Upgrade quality", see
     * [PlaybackService.upgradeQualityNow][com.music.bitchord.playback.PlaybackService].
     *
     * Both sets this clears hold a *no*: asked and answered, or broke on its
     * last swap. Each is the right answer for the automatic path, which has no
     * way to know anything has changed and would otherwise never look at this
     * track again for the rest of the session. Neither survives being
     * contradicted by the listener.
     *
     * Nothing else is disturbed: a lookup already in flight for this track is
     * the answer being waited for, not a stale one, and the item it was started
     * against is the item still playing.
     */
    fun askByHand(mediaId: String) {
        handAsked += mediaId
        asked -= mediaId
        refused -= mediaId
    }

    /**
     * Abandons the second look for every track at once, because the player all
     * of it was about is gone.
     *
     * Everything in this file is scoped to the *process*, and the player it
     * describes is scoped to [PlaybackService][PlaybackService]. Those are not
     * the same lifetime: closing the app destroys the service — by
     * `onTaskRemoved`, or by the session simply being stopped — and Android
     * routinely keeps the process to stand a new one up in. So a second service
     * inherits the first one's verdicts, and the one verdict that matters is
     * [asked].
     *
     * That is the whole of "it never comes back to lossless again". Measured on
     * one track, with the process surviving throughout — a single log buffer
     * holds both halves:
     *
     * ```
     *   15:12:06  auditioning upgraded AdEKgwUqPKI … (FLAC)
     *   15:12:11  upgraded to FLAC at 4759ms       ← and so: asked += AdEKgwUqPKI
     *   ——— app closed, service destroyed, process kept ———
     *   15:13:38  AdEKgwUqPKI <- audio/opus 48.0kHz
     *             (no second look, no search, nothing)
     * ```
     *
     * Selecting the same track in the next service can still play the lossy
     * copy straight from the base cache, with no resolve at all. What is
     * supposed to happen next is [adoptUnresolved], which exists for precisely
     * that track and says so. It never ran: [couldStillUpgrade] found the id in
     * [asked], put there by last session's *successful* upgrade, and refused.
     *
     * So the sets that are meant to outlive a queue movement are given the one
     * boundary they were missing. Clearing them when a new service starts makes
     * a warm restart behave like a cold one — see [PlaybackService.onCreate].
     *
     * [StreamChoice] is deliberately *not* reset alongside this. It records
     * which source is filling each on-disk cache entry, those entries outlive
     * the process, and letting a fresh resolve pick a different source for a
     * half-filled one is the corruption it was written to prevent.
     */
    fun forgetLastSession() {
        // Via [forget] rather than by clearing the maps, so a track still being
        // auditioned or still holding a live lookup is torn down properly — and
        // so the badge for it goes out with it.
        (pending.keys + followUps.keys + forced.keys + shelved.keys + auditioning).forEach(::forget)
        asked.clear()
        refused.clear()
    }

    /**
     * The quality ceiling just dropped — Settings, a move onto mobile data, or
     * the watch taking the music. Everything here that was found, or is still
     * being looked for, under the old one stops counting.
     *
     *  - A live lookup still running for a [pending] track was started against
     *    sources the new ceiling may not pay for. It is cancelled, and the
     *    track left pending, so the second look runs [SourceResolver.upgradeFor]
     *    afresh against the sources the new ceiling allows.
     *  - [followUps] only ever exist to chase a lossless copy, which a lowered
     *    ceiling is by definition no longer asking for.
     *  - A [shelved] or [forced] stream from a source the new ceiling skips is
     *    dropped — except a forced one in [keep]: that is the copy the player
     *    is reading right now, and every re-open of it has to reach the same
     *    bytes. It plays out and the next track honours the new ceiling.
     */
    fun onCeilingLowered(keep: Set<String>, permitted: (SourceStream) -> Boolean) {
        pending.replaceAll { _, waiting ->
            waiting.inFlight?.cancel()
            waiting.copy(inFlight = null)
        }
        followUps.values.forEach { it.inFlight?.cancel() }
        followUps.clear()
        shelved.entries.removeIf { !permitted(it.value) }
        forced.entries.removeIf { (mediaId, stream) -> mediaId !in keep && !permitted(stream) }
    }

    // ── Handing the stream to the player ────────────────────────────────────

    /** Parks [stream] for [mediaId], to be picked up when the item is reopened. */
    fun force(mediaId: String, stream: SourceStream) {
        forced[mediaId] = stream
    }

    /**
     * Re-arms the lossless pass only after the lossy stream has actually
     * swapped in. A failed audition must leave the original search as the last
     * word rather than triggering a second interruption attempt.
     */
    fun continueAfterLossySwap(mediaId: String): Boolean {
        val next = followUps.remove(mediaId) ?: return false
        pending[mediaId] = next
        asked -= mediaId
        NerdStats.onLosslessRaceStart(mediaId)
        return true
    }

    /**
     * The upgraded stream for a request carrying the [MARKER], or null.
     *
     * Read rather than consumed: ExoPlayer reopens a source more than once
     * over a track's life — a seek past the buffer, a resumed playback, a
     * cache miss — and each of those has to arrive at the same bytes.
     */
    fun forcedStream(uri: Uri): SourceStream? {
        if (uri.getQueryParameter(MARKER)?.startsWith(UPGRADED) != true) return null
        return uri.getQueryParameter("v")?.let(forced::get)
    }

    /** The same URI, marked so Media3 rebuilds it and each upgrade gets its own cache entry. */
    fun upgradedUri(uri: String): String {
        // This marker is always appended by this method, so retaining the URI
        // as text avoids reparsing an otherwise opaque custom URI and keeps
        // the generation logic usable in plain JVM tests.
        val markerStart = "&$MARKER="
        val previous = uri.substringAfter(markerStart, missingDelimiterValue = "")
            .substringBefore('&')
            .ifBlank { null }
            // The rendition a revert installed is not a generation of upgrade
            // to count from — it is the thing being upgraded away from. Read as
            // one, the first swap after a revert came out as `hifi-2`, which
            // [PlaybackService.swapPointFor] refuses outright, so the lossless
            // pass that normally follows a lossy improvement could never run.
            ?.takeUnless { it == ORIGINAL }
        val previousGeneration = previous
            ?.removePrefix("$UPGRADED-")
            ?.toIntOrNull()
            ?: 1
        val tag = if (previous == null) UPGRADED else "$UPGRADED-${previousGeneration + 1}"
        // Upgrade markers are appended by this method and are always the final
        // parameter. Replacing rather than duplicating it matters: Android
        // returns the first duplicate, which would send the second stream back
        // into the first upgrade's cache entry.
        return uri.substringBefore(markerStart)
            // The one parameter that has to be dropped rather than carried
            // over. A reverted item says "this exact YouTube rendition,
            // immediately", and the resolving data source honours that before
            // it ever looks for a forced stream — so an upgrade built on top of
            // one would cut the audio and be handed back the very copy it was
            // replacing. It is gone from the item because the listener asked
            // for it to be; see [askByHand].
            .replace("&$DIRECT_YOUTUBE_PARAMETER=1", "") + "$markerStart$tag"
    }

    /**
     * The suffix that keeps an upgraded track's bytes off the copy it
     * replaced — see [AudioCache]'s key factory for why sharing one entry
     * between two renditions corrupts both.
     */
    fun cacheTag(uri: Uri): String? = uri.getQueryParameter(MARKER)
}
